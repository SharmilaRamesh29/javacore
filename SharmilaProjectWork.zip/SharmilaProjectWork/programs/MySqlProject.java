package studentproject;
import java.sql.SQLException;
import java.util.Scanner;

public class MySqlProject {

	public static void main(String[] args)  throws SQLException {

		
		Scanner sc = new Scanner(System.in);
		System.out.println("***********Course Details*********");
		StudentDetails.DisplayCourse();
			//MENU
			
			while(true) {
				System.out.println("======================================================================");
			System.out.println("Enter your choice");
			System.out.println("1. Display Record");
			System.out.println("2. Add new Record");
			System.out.println("3. Update record based on need");
			System.out.println("4. Delete record based on id");
			int ch=sc.nextInt();
			
			switch(ch) {
			case 1: StudentDetails.displayRecord();
			         break;
			case 2: StudentDetails.addRecord();
			          break;
			case 3: StudentDetails.updateRecord();
			         break;
			case 4: StudentDetails.deleteRecord();
			         break;
			default : System.out.println("Invalid input");
			            
			}
			System.out.println("Do you want to contine y/n");
			char choice=sc.next().toLowerCase().charAt(0);
			if(choice!='y') {
				break;
			}
			}
			System.out.println("Program is terminated");
	     }
	}


