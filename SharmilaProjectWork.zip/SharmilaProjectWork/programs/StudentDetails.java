package studentproject;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;
public class StudentDetails {
	private static Connection connection;
	private static Scanner sc;
	private static ResultSet rs;
	private static PreparedStatement pst;
	private static int id , choice,sid,cid;
	private static  String sname,sel,course,sphone,semail,saddress;

	public static void DisplayCourse() throws SQLException {
		connection=DatabaseConnection.getConnection();
		String sel="select * from course";
		pst = connection.prepareStatement(sel);
		rs=pst.executeQuery();
		System.out.println("CourseID\tCourseName\t\t\t\tCourseFees\t\t\t\tCourseDuration");
		while(rs.next()) {
			System.out.println(rs.getInt(1)+"\t\t"+rs.getString(2)+"\t\t\t\t\t"+rs.getString(3)+"\t\t\t\t\t"+rs.getString(4));
		}
	}

	
	public static void addRecord() throws SQLException {
		connection = DatabaseConnection.getConnection(); //getting connection
		//adding record accept , sid, and sname
		sc = new Scanner(System.in);
		System.out.println("enter student id");
		sid=sc.nextInt();
		sc.nextLine();
		System.out.println("Enter student name");
		sname = sc.nextLine();
		System.out.println("Enter student phonenumber");
		sphone=sc.next();
		System.out.println("enter student emailid");
		semail=sc.next();
		sc.nextLine();
		System.out.println("Enter student address");
		saddress=sc.nextLine();
		System.out.println("enter the course id");
		cid=sc.nextInt();
		
		//check sid exists or not
		
		
		sel = "select * from student where sid=?";
		
		pst = connection.prepareStatement(sel);
		pst.setInt(1,sid);
		rs = pst.executeQuery(); 
		if(!rs.next()) { 
			String ins = "insert into student values(?,?,?,?,?,?)";
			pst = connection.prepareStatement(ins);
			pst.setInt(1, sid);
			pst.setString(2, sname);
			pst.setString(3, sphone);
			pst.setString(4, semail);
			pst.setString(5, saddress);
			pst.setInt(6, cid);
			int retval = pst.executeUpdate(); //for insert , update , delete use executeUpdate
			if(retval>0) {
				System.out.println("Record inserted");
				System.out.println("******After insertion*******");
				displayRecord();
			}else {
				System.out.println("Error occured");
			}
	}
		else {
			System.out.println(sid+" already exists ");
		}
	
 }
	public static void displayRecord() throws SQLException {
		connection=DatabaseConnection.getConnection();
		String sel="select * from student";
		pst = connection.prepareStatement(sel);
		rs=pst.executeQuery();
		System.out.println("sid\t\t\tsname\t\t\tsphone\t\t\tsemail\t\t\tsaddress");
		while(rs.next()) {
			System.out.println(rs.getInt(1)+"\t\t"+rs.getString(2)+"\t\t\t\t"+rs.getString(3)+"\t\t"+rs.getString(4)+"\t\t"+rs.getString(5));
		}
	}
	public static void updateRecord() throws SQLException {//for update record should exists
		System.out.println("Before update");
		displayRecord();
		 
		System.out.println("which one you want to update");
		System.out.println("1. To change name");
		System.out.println("2.To change the phone number");
		System.out.println("3. To change the email id");
		System.out.println("4.To change the student address");
		System.out.println("5.To change the course id ");
		sc=new Scanner(System.in);
		int choice=sc.nextInt();
		switch(choice) {
		case 1:
		{
			System.out.println("enter name to change");
			sname=sc.next();
			System.out.println("enter id");
			sid=sc.nextInt();
			String upd=("update student set sname=? where sid=?");
			pst=connection.prepareStatement(upd);
			pst.setString(1,sname);
			pst.setInt(2,sid);
			int retval=pst.executeUpdate();
			if(retval>0){
				System.out.println("student name updated successfully!!!!!!!!");
				
			}
			else {
				System.out.println("Error occured");
			}
		}
		break;
		case 2:	{
			System.out.println("enter phone number to change");
			sphone=sc.next();
			System.out.println("enter id");
			sid=sc.nextInt();
			String upd=("update student set sphone=? where sid=?");
			pst=connection.prepareStatement(upd);
			pst.setString(1,sphone);
			pst.setInt(2,sid);
			int retval=pst.executeUpdate();
			if(retval>0){
				System.out.println("student phone number updated successfully!!!!!!!!");
				
			}
			else {
				System.out.println("Error occured");
			}
		}
		break;
		case 3:	{
			System.out.println("enter the student mail id to change");
			semail=sc.next();
			System.out.println("enter id");
			sid=sc.nextInt();
			String upd=("update student set semail=? where sid=?");
			pst=connection.prepareStatement(upd);
			pst.setString(1,semail);
			pst.setInt(2,sid);
			int retval=pst.executeUpdate();
			if(retval>0){
				System.out.println("student semail updated successfully!!!!!!!! ");
				
			}
			else {
				System.out.println("Error occured");
			}
		}
		break;
		case 4:{
			System.out.println("enter the address you want to change");
			sc.nextLine();
			saddress=sc.nextLine();
			System.out.println("enter id");
			sid=sc.nextInt();
			String upd =("update student set saddress=?where sid=?");
			pst=connection.prepareStatement(upd);
			pst.setString(1,saddress);
			pst.setInt(2,sid);
			int retval=pst.executeUpdate();
			if(retval>0){
				System.out.println("student address  updated successfully!!!!!!!!");
				
			}
			else {
				System.out.println("Error occured");
			}
		}
		break;
		case 5:{
			System.out.println("enter the course id you want to change");
			cid=sc.nextInt();
			sc.nextLine();
			System.out.println("enter id");
			sid=sc.nextInt();
			String upd =("update student set cid=? where sid=?");
			pst=connection.prepareStatement(upd);
			pst.setInt(1,cid);
			pst.setInt(2,sid);
			int retval=pst.executeUpdate();
			if(retval>0){
				System.out.println("student course id updated successfully!!!!!!!! ");
				
			}
			else {
				System.out.println("Error occured");
			}
		}
		break;
		}
	}
			
	public static void deleteRecord() throws SQLException {	
		System.out.println("Before Deletion");
		displayRecord();
		connection = DatabaseConnection.getConnection();
		sc = new Scanner(System.in);
		System.out.println("Enter id");
		id= sc.nextInt();
		
		sel = "select * from student where sid=?";
		pst = connection.prepareStatement(sel);
		pst.setInt(1, id);
		rs = pst.executeQuery();
		
		if(rs.next()) {
			String del = "delete from student where sid=?";
			pst = connection.prepareStatement(del);
			pst.setInt(1, id);
			int retval=pst.executeUpdate();
			if(retval>0) {
				System.out.println("Record is deleted");
				System.out.println("After deleteion");
				displayRecord();
				
			}else {
				System.out.println("Error occurred");
			}
		}else {
			System.out.println(id+" not exists");
		}
		
	}
}
